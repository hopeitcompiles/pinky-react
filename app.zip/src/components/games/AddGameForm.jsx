import { useEffect, useState } from "react"
import Style from "../../assets/css/Form.module.css"
import catchError from "../../services/ErrorCatcher"
import { RegisterGame } from "../../services/GameService"

const gamesTypes=[
    {'value':'UNITY','name':'Unity'},
    {'value':'UNREALENGINE','name':'Unreal Engine'},
    {'value':'JAVASCRIPT','name':'JavaScript'}
]

export function AddGameForm({game_edit,on_success}){
    const [id,setId] = useState(game_edit?game_edit?.id:null)
    const [title,setTitle] = useState(game_edit?game_edit?.title:'')
    const [type,setType] = useState(game_edit?game_edit?.type:'UNDEFINED')
    const [description,setDescription] = useState(game_edit?game_edit?.description:'')
    const [about,setAbout] = useState(game_edit?game_edit?.about:'')
    const [error,setError] = useState('')

    const handleRegister=async (e) =>{
        setError("")
		e.preventDefault();
        if(
            title===game_edit?.title &&
            type===game_edit?.type &&
            about===game_edit?.about &&
            description===game_edit?.description
        ){
            setError("Nothing to change")
            return;
        }
		let game={id,title,type,about,description}
        console.log(game)
		try{
            const response=await RegisterGame(game)
            if(response?.status===200){
                setError(game_edit?'Updated!':'Registered!')
            }else if(response?.status===208){
                setError('Title game is already registered')
            }
		}catch(er){
			setError(catchError(er))
		}
	}
    useEffect(()=>{
        return ()=>{
            if(on_success){
                on_success()
            }
        }
    },[])

    return (<form className={Style.form} onSubmit={handleRegister}>
                <input type="hidden"
                    value={game_edit?game_edit.id:''}/>
                <input className={Style.input_form} 
                    type="text" 
                    placeholder="Title" 
                    onChange={(e) => setTitle(e.target.value)}
                    value={title} required/>
                <input className={Style.input_form} 
                    type="text" 
                    placeholder="Short description" 
                    onChange={(e) => setAbout(e.target.value)}
                    value={about} required/>
                <textarea className={Style.input_form} 
                    type="area" 
                    placeholder="Detailed description" 
                    onChange={(e) => setDescription(e.target.value)}
                    value={description} required/>
                {!game_edit&&
                    <select className={Style.input_form} 
                        type={`${game_edit?'text':'hidden'}`} 
                        onChange={(e) => setType(e.target.value)} value={type}>
                            <option  value="UNDEFINED" disabled>Choose the platform</option>
                            {gamesTypes.map((item)=>{
                                return <option key={item.value} value={item.value}>
                                {item.name}</option>
                            })
                            }
                    </select>
                }
                <h6 style={{'color':'red',
                'fontSize':'x-small','fontWeight':'700'}}>{game_edit?
                "Game type can't be changed":
                "This option is permanent"}
                </h6>

                <h6 className={Style.error} >{error}</h6>
                <button type="submit" className={Style.btn_form}
                    >{game_edit?'Update':'Register'}
                </button>
            </form>
    )
}